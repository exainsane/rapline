		<div class="col s12 l9" style="min-height:500px">
			<blockquote class="border-blue"><h4>Panduan Penggunaan Aplikasi</h4></blockquote>
			<ol>
				<li>Gunakan fitur <i>Dapatkan Password</i> untuk mendapatkan password anda.<br>
					<small><i><strong>password akan dikirimkan via E-Mail</strong></i></small>
				</li>
				<li>Login dengan menggunakan nomor identitas anda (<strong>NIP</strong> untuk guru atau <strong>NIS</strong> untuk siswa)</li>
				<li>Setelah login, anda akan dibawa ke menu utama.
					<ul>
						<li>&nbsp;<i>Siswa dapat mengunduh form nilai dan jadwal pelajaran</i></li>
						<li>&nbsp;<i>Guru dapat menginput data administrasi siswa dan menginput nilai</i></li>
					</ul>
				</li>
			</ol>
		</div>