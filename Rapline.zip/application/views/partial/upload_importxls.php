<div class="row">
	<form action="<?php echo site_url("actions/import") ?>" method="POST" enctype="multipart/form-data">
	<input type="file" name="doc">
	<input type="submit">
	</form>
</div>