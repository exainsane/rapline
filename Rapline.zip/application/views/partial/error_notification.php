<div class="col s12 fillarea">
	<h4><?php echo $error ?></h4>
	<?php if (isset($resolve)): ?>
		<p><?php echo $resolve ?></p>
	<?php endif ?>
</div>