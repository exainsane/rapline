<div class="row">
	<div class="col s12">
		<ul class="collection">
			:[content]:
		</ul>
	</div>
</div>