<div class="row">
	<div class="col s12">
		<ul class="collection">
			:[content]:
		</ul>
		<form action=":[form_action]:" method="POST">
			<input type="hidden" name="form_input" value="true">
			<input type="hidden" name="cred" value=":[cred_value]:">
			<button class="btn red darken-1">Get Password</button>
		</form>
	</div>
</div>