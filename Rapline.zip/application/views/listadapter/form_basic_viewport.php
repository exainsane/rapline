<div class="input-field">
  <input placeholder=":[placeholder]:" id=":[id]:" type="text" name=":[inputname]:" class="validate">
  <label for=":[id]:">:[title]:</label>
</div>