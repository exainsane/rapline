<div class="row">
	<h5 class="">:[title]:</h5>
	<div class="col s12">
		<form method="POST">
			<input type="hidden" value=":[tbname]:" name="table">
			:[content]:
			<button class="btn btn-flat">:[submittext]:</button>
		</form>
	</div>
</div>