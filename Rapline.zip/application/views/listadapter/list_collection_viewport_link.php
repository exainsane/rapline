<li class="collection-item"><a href=":[href]:">:[link]:</a></li>
